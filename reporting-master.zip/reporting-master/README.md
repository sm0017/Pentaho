reporting
=========

Transformations, config, etc. for generating reports
